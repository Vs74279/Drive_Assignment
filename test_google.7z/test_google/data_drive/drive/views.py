from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib import messages
from django.db import connection
from django.contrib.auth import authenticate,login,logout
from drive.models import Folder,File
 

# Middleware (Custom Middleware for Logging Requests)
class LogMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        print(f"Request Method: {request.method}, Path: {request.path}")
        response = self.get_response(request)
        return response
    
def index(request):
    if request.user.is_authenticated:
        # Make sure folders are being retrieved correctly
        folders = Folder.objects.filter(folderuser=request.user)
        context = {'folder': folders}
        return render(request, 'index.html', context)
    else:
        return redirect('signup')

# Folder with files in it
def folder(request, folderid):
    if request.user.is_authenticated:
        # Get the folder
        folder_user = Folder.objects.get(id=folderid)
        
        # Get files in the folder (Querying through the File model)
        files = File.objects.filter(folder=folder_user)
        
        # Handle file upload
        if request.method == 'POST' and request.FILES.get('file'):
            file_user = request.FILES.get('file')  # Getting the uploaded file
            file_title = request.POST.get('filetitle')  # Getting the title of the file

            # Create a new file record and save the file
            File.objects.create(filetitle=file_title, file=file_user, folder=folder_user)
            messages.success(request, "File uploaded successfully!")
            return redirect('folder', folderid=folderid)  # Redirect back to the folder page
        
        # Prepare context data to render in the template
        context = {'folderid': folderid, 'folder': folder_user, 'files': files}
        
        return render(request, 'folder.html', context)
    else:
        return redirect('signup')
# Update Folder View
def update_folder(request, folderid):
    folder = Folder.objects.get(id=folderid)
    
    if request.method == 'POST':
        folder.foldername = request.POST['foldername']
        folder.folderdesc = request.POST['desc']
        folder.save()
        messages.success(request, "Folder updated successfully!")
        return redirect('folder', folderid=folder.id)

    context = {'folder': folder}
    return render(request, 'update_folder.html', context)

# Delete Folder View
def delete_folder(request, folderid):
    folder = Folder.objects.get(id=folderid)
    
    if request.method == 'POST':
        folder.delete()
        messages.success(request, "Folder deleted successfully!")
        return redirect('index')

    context = {'folder': folder}
    return render(request, 'delete_folder.html', context)

# Update File View
def update_file(request, fileid):
    file = File.objects.get(id=fileid)
    
    if request.method == 'POST':
        file.filetitle = request.POST['filetitle']
        if 'file' in request.FILES:
            file.file = request.FILES['file']
        file.save()
        messages.success(request, "File updated successfully!")
        return redirect('folder', folderid=file.folder.id)

    context = {'file': file}
    return render(request, 'update_file.html', context)

# Delete File View
def delete_file(request, fileid):
    file = File.objects.get(id=fileid)
    
    if request.method == 'POST':
        file.delete()
        messages.success(request, "File deleted successfully!")
        return redirect('folder', folderid=file.folder.id)

    context = {'file': file}
    return render(request, 'delete_file.html', context)



# Add Folder View
def addfolder(request):
   if request.method == 'POST':
       folder_name = request.POST['foldername']
       folder_desc = request.POST['desc']
       folder = Folder.objects.create(foldername=folder_name,folderdesc=folder_desc,folderuser=request.user)
       if folder:
           return redirect("index")
       else:
            messages.error(request,"Folder Not Created")
            return redirect("index")
# View For SignUp the user
def SignUp(request):
    if request.user.is_authenticated:
        return redirect('index')
    else:
        if request.method == 'POST':
            username = request.POST['username']
            email = request.POST['email']
            password = request.POST['password']
            cpassword = request.POST['cpassword']
            firstname = request.POST['fname']
            lname = request.POST['lname']
            if username and password and email and cpassword and firstname and lname:
                if password == cpassword:
                    user = User.objects.create_user(username,email,password)
                    user.first_name = firstname
                    user.last_name = lname
                    user.save()
                    if user:
                        messages.success(request,"User Account Created")
                        return redirect("login")
                    else:
                        messages.error(request,"User Account Not Created")
                else:
                    messages.error(request,"Password Not Matched")
                    redirect("signup")
        return render(request,'signup.html')
    
# View For Log in the user
def Login(request):
    if request.user.is_authenticated:
        return redirect("login")
    else:
        if request.method == 'POST':
            username = request.POST['username']
            password = request.POST['password']
            if username and password:
                user = authenticate(username=username,password=password)
                if user is not None:
                    login(request,user)
                    return redirect('index')
        return render(request,'login.html')
# User logout function
def Logout(request):
    logout(request)
    return redirect("index")