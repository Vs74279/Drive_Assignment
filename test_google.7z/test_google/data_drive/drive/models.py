from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Folder(models.Model):
    foldername = models.CharField(max_length=50)
    folderdesc = models.TextField()
    folderuser = models.ForeignKey(User,on_delete=models.CASCADE)
    parent = models.ForeignKey('self', null=True, blank=True, related_name='subfolders', on_delete=models.CASCADE)
    

    def __str__(self):
        return self.foldername
class File(models.Model):
    filetitle = models.CharField(max_length=50)
    folder = models.ForeignKey(Folder,on_delete=models.CASCADE)
    file = models.FileField(upload_to="Files")