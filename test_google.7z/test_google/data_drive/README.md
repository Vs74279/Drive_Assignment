# Data Drive System

## Project Description
The Data Drive System is a file storage and management system similar to Google Drive, built using Django (version 3+), middleware, ORM, and Raw SQL queries. The system allows users to create accounts, log in, and perform CRUD operations on files and folders. Users can also create folders inside folders, supporting multiple levels of folder hierarchy, like Google Drive.

## Key Features
- Users can perform CRUD (Create, Read, Update, Delete) operations on files and folders.
- Users can create and manage folders up to nth depth (folders inside folders).
- Users can create accounts and log in. (Note: Forget password feature is not required).
  
## Project Setup

### Prerequisites
Before running the project, ensure you have the following installed on your machine:

- Python 3.8 or higher
- Django 3+ (or compatible version)
- SQLite (or another database as configured in `settings.py`)

### Install Dependencies
Clone the repository and install the required dependencies.

```bash
git clone https://github.com/yourusername/data-drive-system.git
cd data-drive-system
pip install -r requirements.txt
